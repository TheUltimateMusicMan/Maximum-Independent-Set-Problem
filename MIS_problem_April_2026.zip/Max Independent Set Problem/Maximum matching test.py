# -*- coding: utf-8 -*-
"""
Created on Thu Apr 23 08:27:44 2026

@author: Scott
"""

import networkx as nx

G = nx.Graph()

V = []
E = []

with open("graph_1000_intermediate.txt", "r") as f:
    lines = f.readlines()
    exec(lines[0])  # sets V
    exec(lines[1])  # sets E


for edge in E:
    v1, v2 = edge
    G.add_edge(v1, v2)


M = nx.max_weight_matching(G, maxcardinality=True)

print(len(M))
