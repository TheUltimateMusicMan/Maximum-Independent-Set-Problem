# -*- coding: utf-8 -*-
"""
Created on Sat Apr  4 00:38:53 2026

@author: Scott


This file is used for quick testing/running the different algorithms I implemented
for finding the largest independent set of a graph.

"""


import StaticGraphs
import time
import Find_Largest_Independent_Set as mis


def write_results_to_txt(filename, p, values):
    """
    filename: output txt file
    p_values: list of p values
    results_dict: dict mapping p -> list of 1000 max sizes
    """

    with open(filename, "a") as f:

        # write block
        f.write(f"p={p}\n")
        f.write(",".join(map(str, values)) + "\n\n")


def write_dist_to_txt(filename2, p, dist):
    """
    filename: output txt file
    p_values: list of p values
    results_dict: dict mapping p -> list of 1000 max sizes
    """

    with open(filename2, "a") as f:
        f.write(f"p={p}\n")
        f.write(str(dist) + "\n\n")


#==============================================================================

filename = "phase_4_results.txt"
filename2 = "phase_4_distribution.txt"

p_values = [0.5]
tests = 10 # per p value
budget = 100000



V = []
E = []


with open("graph_1000_intermediate.txt", "r") as f:
    lines = f.readlines()
    exec(lines[0])  # sets V
    exec(lines[1])  # sets E


G = StaticGraphs.StaticGraph((V, E))

print("Starting")

p = 0

start = time.time()



for p in p_values:
    largest_ind_sizes = []
    
    relocations = max(1, int(budget ** p))
    max_steps = max(1, budget // relocations)
    
    
    print("Trial info: " + f"p={p}, relocations={relocations}, max_steps={max_steps}")
    
    for i in range(tests):
        largest_ind_sizes.append(mis.find_large_ind_set_nomadic_random_greedy_walk_2(G, relocations, max_steps))
    
    distribution = {}
    
    for size in largest_ind_sizes:
        if size not in distribution:
            distribution[size] = 1
        else:
            distribution[size] += 1
    
    print(distribution)
    
    write_results_to_txt(filename, p, largest_ind_sizes)
    write_dist_to_txt(filename2, p, distribution)
    
end = time.time()

print("Total run time: " + str(end - start) + " seconds")





