from libcpp.vector cimport vector
from libcpp.utility cimport pair
from libcpp.bool cimport bool

cdef extern from "vector" namespace "std":
    cdef cppclass vector[T]:
        vector() except +
        void push_back(T&) except +
        T& operator[](size_t) except +
        size_t size() except +

cdef class graph:
    
    vector[int] vertices
    vector[vector[pair[int, int]]] edges
    vector[vector[int]] adjacency
    bool digraph
    vector[int] coloring
    vector[vector[int]] inv_coloring
    vector[int] sequence
    vector[bool] forbidden
    
    # C++ methods
    graph() except +
    void initialize_standard(vector[int] V, vector[pair[int,int]] E) except +
    vector[int] find_large_ind_set() except +
    void shuffle_sequence() except +
