from setuptools import setup
from Cython.Build import cythonize
from setuptools.extension import Extension

import numpy as np
import glob
import os

# Get all .pyx files in the current folder
pyx_files = glob.glob("*.pyx")


extensions = [
    Extension(
        "Find_Largest_Independent_Set",
        ["Find_Largest_Independent_Set.pyx"],
        language="c++",  # <-- important!
        extra_compile_args=["-O3"],  # optional optimization
    ),
    Extension(
        "Graphs",
        ["Graphs.pyx"],
        language="c++",  # <-- important!
        extra_compile_args=["-O3"],  # optional optimization
    )
]

# Build extensions with NumPy headers
setup(
    name="GraphLibrary",
    ext_modules=cythonize(pyx_files, compiler_directives={'language_level': "3"}),
    include_dirs=[np.get_include()]
)
#python setup.py build_ext --inplace

