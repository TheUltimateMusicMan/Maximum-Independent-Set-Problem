# -*- coding: utf-8 -*-
"""
Created on Tue Apr 21 11:45:27 2026

@author: Scott
"""

import numpy as np
import matplotlib.pyplot as plt
import ast





with open("Test_April_2026_distributions.txt", "r") as f:
    lines = f.readlines()

distributions = {}
p_values = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]

global_max_size = 0
global_min_size = 1000

for i in range(0, len(lines), 3):
    p_value_ind = i
    line_ind = i + 1
    
    p = lines[p_value_ind]
    p = p.strip() # line is now a string representation of a dictionary
    p = float(p.split("=")[-1])
    
    distribution = lines[line_ind]
    distribution = distribution.strip()
    distribution = ast.literal_eval(distribution)
    distributions[p] = distribution
    
    if global_max_size < max(distribution):
        global_max_size = max(distribution)
    
    if global_min_size > min(distribution):
        global_min_size = min(distribution)
    
#print(distributions)


#plotting size distributions

for p_value in distributions:
    distribution = distributions[p_value]
    
    size_counts = np.zeros(global_max_size - global_min_size + 1)
    sizes = list(range(global_min_size, global_max_size + 1))
    for size in sizes:
        if size in distribution:
            size_counts[size - global_min_size] = distribution[size]
        else:
            size_counts[size - global_min_size] = 0
            
    barplot = plt.bar(sizes, size_counts)
    plt.bar_label(barplot, fontsize=8)  # optional styling
    plt.title("Set Size Distribution for p = " + str(p_value))
    plt.xlabel("Size")
    plt.ylabel("Count")
    plt.ylim(0, 1000)
    plt.show()


#plotting mean max size vs p value


with open("Test_April_2026_results.txt", "r") as f:
    lines = f.readlines()
    exec(lines[0])  # sets V
    exec(lines[1])  # sets E


means = []
max_sizes = []

for i in range(1, len(lines), 3):
    line = lines[i]
    line = line.strip()
    values = line.split(",")
    values = list(map(int, values))
    mean = np.mean(values)
    max_size = max(values)
    means.append(mean)
    max_sizes.append(max_size)

plt.plot(p_values, means, marker = ".", color="red", label="Mean size")
plt.plot(p_values, max_sizes, marker = ".", color="blue", label="Max size")
plt.legend()
plt.title("Mean and Maximum Sizes for each p")
plt.xlabel("p")
plt.ylabel("Size")

