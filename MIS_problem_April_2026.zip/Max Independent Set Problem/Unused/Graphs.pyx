

# cython: language_level = 3
# distutils: language=c++

# -*- coding: utf-8 -*-
"""
Created on Sat Oct  4 19:30:46 2025

@author: Scott

This is the graph class file, along with its functions, written for Cython.
Designed to run at high speed. A Python-only version is available.
"""

cimport Graphs

from libcpp.vector cimport vector
from libcpp.pair cimport pair
from libcpp.random cimport mt19937 as randomizer
from libcpp.random cimport uniform_int_distribution as unint_dist
from libc.time cimport time

cimport numpy as np
cimport cython
from libc.stdlib cimport malloc, free

import Graph_utilities as gutil
import numpy as np


cdef randomizer rng
cdef unsigned int seed = <unsigned int>time(NULL)
rng.seed(seed)


vector[int] vertices
vector[vector[pair[int, int]]] edges
vector[vector[int]] adjacency
bool digraph
vector[int] coloring
vector[vector[int]] inv_coloring
vector[int] sequence
vector[bool] forbidden
    
cdef void Graph_initialize_standard(Graphs.graph* G, vector[int] V, vector[pair[int,int]] E):
    cdef int vertex, a, b

    # Copy vertices and edges
    G.vertices = V
    G.edges = E

    # Initialize adjacency lists
    for vertex in V:
        G.adjacency.push_back(vector[int]())
        G.forbidden.push_back(False)

    # Fill adjacency for undirected edges
    for a, b in E:
        G.adjacency[a].push_back(b)
        G.adjacency[b].push_back(a)

    # Copy vertices into sequence
    G.sequence = vector[int](V)

    # Initialize coloring and inv_coloring as empty
    G.coloring = vector[int]()
    G.inv_coloring = vector[vector[int]]()
    

def get_standard_format(self):
    
    """Returns the standard format for the graph object."""
    
    return (self.vertices, self.edges)


def get_neighbor_format(self):
    
    """Returns an adjacency list format for the graph."""
    
    return self.adjacency
    
    
    #graph modification methods ===============================================
    
    """def delete_vertex(self, vertex, incident_format = None):
        
        self.vertices.remove(vertex)
        
        if incident_format == None:
            for edge in self.edges.copy():
                if vertex in edge:
                    self.edges.remove(edge)
        
        else:
            
            incident_edges = incident_format[vertex]
            for edge in incident_edges:
                self.edges.remove(edge)
    
        
    def delete_edge(self, edge):
        backwards_edge = edge[::-1]
        
        if edge in self.edges:
            self.edges.remove(edge)
        elif backwards_edge in self.edges:
            self.edges.remove(backwards_edge)
        
    
    # graph properties methods ===========================================================
    
    
    def is_tree(self):
        '''Checks if the graph is a tree.'''
        
        vertices = self.vertices
        adjacency = self.get_neighbor_format()
        
        tree_status = [True]
        explored_vertices = set()
        
        v = vertices[0]
        
        gutil.__tree_explore_next__(v, "", vertices, adjacency, \
                                    explored_vertices, tree_status)
        
        if len(vertices) == len(explored_vertices) and tree_status[0]: # graph is connected and acyclic
            return True
        else:
            return False
    
    
    def is_connected(self):
        '''Checks if the graph is connected.'''
        
        vertices = self.vertices
        adjacency = self.get_neighbor_format()
        explored_vertices = set()
        v = vertices[0] #arbitrary vertex from vertices, could be the first one
        
        gutil.__conn_explore_next__(v, vertices, adjacency, explored_vertices)
        
        if len(vertices) == len(explored_vertices): # graph is connected
            return True
        else:
            return False
    
    
    def is_bipartite(self):
        
        vertices = self.vertices.copy()
        
        color_map = {vertex: 0 for vertex in vertices}
        
        bipartite_status = [True] # pass by reference for a function-modifiable boolean
        
        while len(vertices) > 0 and bipartite_status[0]: # repeat until all components are visited
        
            vertex = vertices[0] # start in a component
            adjacency = self.get_neighbor_format()
            
            explored_vertices = set()
            
            gutil.__bipartite_explore_next__(vertex, color_map, vertices, \
                                             adjacency, explored_vertices, \
                                                    bipartite_status, 1)
        
        return bipartite_status[0]
    
    
# path and distance methods

    def find_shortest_path(self, u, v, adjacency = None):
        
        '''Return the shortest path in graph from u to v, complete
        with the vertices and edges.'''
        
        #if u = v, return [u] as the path
        
        if u == v: return graph(([u], []))
        
        #otherwise, continue below.
        #extract the vertices
        
        vertices, edges = self.vertices, self.edges
        
        # build adjacency list
        
        if adjacency == None: # adjacency is an optional parameter in programs that may call this function multiple times for the same graph
            adjacency = {vertex: [] for vertex in vertices}
        
            for (a, b) in edges:
                adjacency[a].append(b)
                adjacency[b].append(a)
        
        #initialize explored, a dictionary with vertices for keys and False for each vertex
        
        explored = {vertex: False for vertex in vertices}
        explored[u] = True
        
        #set radius to 1
        
        radius = 1
        
        #initialize distance_shells. Keys are distance from u, and their items are a list of vertices of that distance from u.
        
        distance_shells = {0: [u]}
        
        parent = {u: None} # parent dictionary for finding path
        
        v_found = False
        
        #while v not found and there are still neighbors left:
        while not v_found and len(distance_shells[radius - 1]) != 0:
            
            shell = distance_shells[radius - 1]
            next_shell = distance_shells[radius] = []
            
            #for each vertex in circular shell
            for vertex in shell:
                
                #find all neighbors of the vertex.
                neighbors = adjacency[vertex]
                
                #for each neighbor adjacent to vertex:
                for neighbor in neighbors:
                    
                    #if the neighbor is v, set v found to true
                    if neighbor == v:
                        explored[v] = True
                        parent[v] = vertex
                        v_found = True
                        
                    #otherwise if the distance of the neighbor is None (the vertex is not yet visited)
                        #set the distance for this vertex to radius
                        #add the neighbor to the next circular shell
                        #assign the parent of the neighbor
                        
                    elif not explored[neighbor]:
                        explored[neighbor] = True
                        next_shell.append(neighbor)
                        parent[neighbor] = vertex
            
            
            #increase radius by 1
            radius += 1
                
        #if v is not found, the graph is disconnected. Return an empty list.
        if not v_found:
            #print(vertices)
            return graph(([], []))
        
        #otherwise, we will find a path from v to u.
        
        #let vertex be v.
        vertex = v
        
        #let the path contain only v
        path_vertices = [v]
        path_edges = []
        
        #Let vertex be its parent
        #Repeat until vertex has no parent
        
        while parent[vertex] != None: # while vertex u is not reached
            #print(radius)
            
            parent_vertex = parent[vertex]
            
            path_vertices.insert(0, parent_vertex)
            
            
            path_edges.insert(0, (parent_vertex, vertex))
            vertex = parent_vertex
        
        
        #return the path
        return graph((path_vertices, path_edges))
    
    
    def greedy_color(self, sequence = None, adjacency = None, coloring = {}):
        
        '''
        Gives a proper coloring for the graph. Also supports re-coloring part of a graph according to new sequences.
        May not be a chromatic coloring.

        '''
        
        if sequence == None:
            sequence = self.vertices
        
        if adjacency == None: # build adjacency list
            
            adjacency = {vertex: [] for vertex in self.vertices}
        
            for (a, b) in self.edges:
                adjacency[a].append(b)
                adjacency[b].append(a)
        
        if coloring == {}:
            coloring = {vertex: None for vertex in adjacency} # create empty coloring
        
        for vertex in sequence:
            
            min_unused_color = 0
            
            colors_used = set() # tracks all colors in the neighborhood of vertex with O(1) lookup
            
            for neighbor in adjacency[vertex]:
                
                current_color = coloring[neighbor]
                
                colors_used.add(current_color)
                
                while min_unused_color in colors_used: # increase min_unused_color until it is not in colors_used.
                    min_unused_color += 1
                
            coloring[vertex] = min_unused_color # assign lowest possible non-conflicting color
            
            
            if min_unused_color in self.inv_coloring: # also add to inverse coloring
                self.inv_coloring[min_unused_color].append(vertex)
            else:
                self.inv_coloring[min_unused_color] = [vertex]
            
            self.coloring = coloring
            
        return coloring
    """
    
    def shuffle_sequence(self):
        """
        This function scrambles the sequence attribute used for vertex-order
        dependent algorithms like greedy coloring and finding a large
        independent set.
        
        Returns: None
        """
        
        cdef vector[int]& sequence = self.sequence
        cdef int N = sequence.size()
        cdef int i, j, temp
        
        cdef unint_dist[int] randint
        
        for i from 0 <= i < N - 1:
            randint = unint_dist[int](i, N-1)
            j = randint(rng)
            temp = sequence[i]
            sequence[i] = sequence[j]
            sequence[j] = temp
    
    

    def find_large_ind_set(self):
        
        cdef vector[int]& sequence = self.sequence
        
        cdef vector[bool]& forbidden = self.forbidden
        
        i = int(0)
        target_flag = forbidden[0]
        cdef int N = sequence.size()
        
        cdef vector[vector[int]]& adjacency = self.adjacency
        cdef int vertex
        cdef vector[int]& neighbors
        
        cdef vector[int] ind_set = vector[int]()
        cdef int s, j
        
        while i < N:
            vertex = sequence[i]
            ind_set.push_back(vertex)
            forbidden[vertex] = target_flag
            
            neighbors = adjacency[vertex]
            s = neighbors.size()
            j = 0
            for j in range(s):
                neighbor = neighbors[j]
                forbidden[neighbor] = target_flag
            
            i += 1
            while i < N and forbidden[sequence[i]] == target_flag: # skip to the next non-forbidden vertex.
                i += 1
            
        return ind_set


"""
cdef class StaticGraph:
    
    '''
    This class of graphs is a class of graphs that cannot be modified after
    creation. These are only meant to be studied for certain NP-hard problems,
    such as finding the largest independent set.
    '''
    
    cdef public list vertices
    cdef public list edges
    cdef public list adjacency
    cdef public bool digraph
    cdef public dict coloring
    cdef public dict inv_coloring
    cdef public int[:] sequence
    
    cdef public bint[:] forbidden # private attribute used in some methods
    
    def __init__(self, graph_data, graph_format = "standard"):
        
        '''Initialize a graph using either tuple format or adjacency format.
        
        Parameters:
            graph_format: str. The format of the graph. Either "standard" or "neighbor".
            
            graph_tuple: optional tuple(list, list). If your graph format is standard, include this tuple.
            
            graph_adjacency: optional dict{str: list}. If your graph format is neighbor, include this dictionary.
        '''
        
        if graph_format == "standard":
            self.vertices, self.edges = graph_data
            
        elif graph_format == "neighbor":
            self.vertices, self.edges = ([], [])
            
            for vertex in graph_data:
                self.vertices.append(vertex)
                
                for other_endpoint in graph_data[vertex]:
                    
                    if not((vertex, other_endpoint) in self.edges or \
                           (other_endpoint, vertex) in self.edges):
                        
                        self.edges.append((vertex, other_endpoint))
                        
        else: # recognize as standard.
            self.vertices, self.edges = graph_data
        
        self.vertices.sort()
        
        self.digraph = True
        
        self.coloring = {}
        
        self.inv_coloring = {}
        
        self.adjacency = []
        
        for vertex in self.vertices:
            self.adjacency.append([])
        for edge in self.edges:
            a, b = edge
            self.adjacency[a].append(b)
            self.adjacency[b].append(a)
        
        cdef int[::1] neighbors
        
        for vertex in self.vertices:
            neighbors_arr = np.array(self.adjacency[vertex], dtype = np.int32)
            neighbors = neighbors_arr
            self.adjacency[vertex] = neighbors

        cdef int N = len(self.vertices)
        
        # allocate raw C array
        cdef bint* c_forbidden = <bint*> malloc(N * sizeof(bint))
        for i in range(N):
            c_forbidden[i] = False  # initialize
        
        # wrap in memoryview
        self.forbidden = <bint[:N]> c_forbidden
        
        
        cdef int[::1] vertex_sequence = np.array(self.vertices, dtype = np.int32)
        
        self.sequence = vertex_sequence
    
    
    def shuffle_sequence(self):
        '''
        This function scrambles the sequence attribute used for vertex-order
        dependent algorithms like greedy coloring and finding a large
        independent set.
        
        Returns: None
        '''
        
        cdef int[:] sequence = self.sequence
        cdef int N = len(sequence)
        cdef int i, j
        
        for i in range(N - 1):
            j = randint(i, N - 1)
            temp = sequence[i]
            sequence[i] = sequence[j]
            sequence[j] = temp
            
    
    
    def find_large_ind_set(self, sequence_input = None):
        '''
        sequence: a Python list of vertices containing the order in which to perform
        the vertex selection in.
        
        Returns: list[int]
        '''
        
        cdef int[:] sequence # cython memoryview sequence for fast access to elements
        cdef int[::1] seq_array
        
        
        if sequence_input is None:
            sequence = self.sequence
        else:
            seq_array = np.array(sequence_input, dtype=np.int32)
            sequence = seq_array
        
        
        #cython-type variables
        cdef int N = len(sequence)
        cdef int i = 0
        cdef bint[:] forbidden = self.forbidden
        cdef bool true = not forbidden[0] # true is the boolean variable storing the target truth for being forbidden.
        cdef int vertex
        cdef int[:] neighbors
        
        #python-type variables
        adjacency = self.adjacency
        ind_set = []
        
        while i < N:
            vertex = sequence[i]
            forbidden[vertex] = true
            ind_set.append(vertex)
            
            neighbors = adjacency[vertex]
            
            for neighbor in neighbors:
                forbidden[neighbor] = true
            
            i += 1
            while i < N and forbidden[sequence[i]] == true: # skip to the next non-forbidden vertex.
                i += 1
            
        return ind_set
            
    
    
#    def welsh_powell_color(self, starting_v = None, adjacency = None):
        
  """

