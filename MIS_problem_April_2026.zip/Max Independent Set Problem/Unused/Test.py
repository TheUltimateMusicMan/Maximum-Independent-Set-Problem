# -*- coding: utf-8 -*-
"""
Created on Sat Apr  4 16:08:07 2026

@author: Scott
"""

import Graphs

K12 = Graphs.StaticGraph((
    [i for i in range(12)],
    [(i, j) for i in range(12) for j in range(i+1,12)]
))

P4 = Graphs.StaticGraph(([0, 1, 2, 3],[(0, 1), (1, 2), (2, 3)]))

C5 = Graphs.StaticGraph(([0, 1, 2, 3, 4], [(0, 1), (1, 2), (2, 3), (3, 4), (4, 0)]))
